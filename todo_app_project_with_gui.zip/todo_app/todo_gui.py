import tkinter as tk
from tkinter import messagebox
import json

class Task:
    def __init__(self, title, description, category, completed=False):
        self.title = title
        self.description = description
        self.category = category
        self.completed = completed

    def mark_completed(self):
        self.completed = True

def save_tasks(tasks, filename='tasks.json'):
    with open(filename, 'w') as f:
        json.dump([task.__dict__ for task in tasks], f, indent=4)

def load_tasks(filename='tasks.json'):
    try:
        with open(filename, 'r') as f:
            return [Task(**data) for data in json.load(f)]
    except FileNotFoundError:
        return []

class ToDoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Personal To-Do List")
        self.tasks = load_tasks()

        self.title_label = tk.Label(root, text="Task Title:")
        self.title_label.grid(row=0, column=0)
        self.title_entry = tk.Entry(root, width=30)
        self.title_entry.grid(row=0, column=1)

        self.desc_label = tk.Label(root, text="Description:")
        self.desc_label.grid(row=1, column=0)
        self.desc_entry = tk.Entry(root, width=30)
        self.desc_entry.grid(row=1, column=1)

        self.cat_label = tk.Label(root, text="Category:")
        self.cat_label.grid(row=2, column=0)
        self.cat_entry = tk.Entry(root, width=30)
        self.cat_entry.grid(row=2, column=1)

        self.add_button = tk.Button(root, text="Add Task", command=self.add_task)
        self.add_button.grid(row=3, column=1, pady=5)

        self.task_listbox = tk.Listbox(root, width=70, height=15)
        self.task_listbox.grid(row=4, column=0, columnspan=2)

        self.complete_button = tk.Button(root, text="Mark Completed", command=self.mark_task_completed)
        self.complete_button.grid(row=5, column=0, pady=5)

        self.delete_button = tk.Button(root, text="Delete Task", command=self.delete_task)
        self.delete_button.grid(row=5, column=1, pady=5)

        self.refresh_tasks()

        root.protocol("WM_DELETE_WINDOW", self.on_closing)

    def add_task(self):
        title = self.title_entry.get()
        description = self.desc_entry.get()
        category = self.cat_entry.get()
        if title.strip() == "":
            messagebox.showwarning("Input Error", "Task title cannot be empty.")
            return
        task = Task(title, description, category)
        self.tasks.append(task)
        self.refresh_tasks()
        self.clear_entries()

    def refresh_tasks(self):
        self.task_listbox.delete(0, tk.END)
        for i, task in enumerate(self.tasks, start=1):
            status = "✔ Completed" if task.completed else "❌ Not Completed"
            self.task_listbox.insert(tk.END, f"{i}. {task.title} - {task.description} [{task.category}] - {status}")

    def mark_task_completed(self):
        try:
            index = self.task_listbox.curselection()[0]
            self.tasks[index].mark_completed()
            self.refresh_tasks()
        except IndexError:
            messagebox.showwarning("Selection Error", "Please select a task to mark completed.")

    def delete_task(self):
        try:
            index = self.task_listbox.curselection()[0]
            del self.tasks[index]
            self.refresh_tasks()
        except IndexError:
            messagebox.showwarning("Selection Error", "Please select a task to delete.")

    def clear_entries(self):
        self.title_entry.delete(0, tk.END)
        self.desc_entry.delete(0, tk.END)
        self.cat_entry.delete(0, tk.END)

    def on_closing(self):
        save_tasks(self.tasks)
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoApp(root)
    root.mainloop()
