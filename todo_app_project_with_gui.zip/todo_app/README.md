# Personal To-Do List Application

## Overview
This is a simple Python-based Personal To-Do List Application. It allows users to add, view, edit, delete, and mark tasks as completed. Tasks are saved locally in a JSON file.

## Features
- Add tasks with title, description, and category.
- View all tasks with completion status.
- Mark tasks as completed.
- Delete tasks.
- Save and load tasks from a JSON file.

## Project Structure
```
/todo_app
 ├── todo.py         # Main application logic
 ├── tasks.json      # File to store tasks
 └── README.md       # Documentation
```

## How to Run
1. Install Python (>=3.7).
2. Clone or download this project folder.
3. Open a terminal in the project directory.
4. Run the application:
   ```bash
   python todo.py
   ```

## Future Enhancements
- Add due dates and reminders.
- Improve GUI using Tkinter.
- Add cloud synchronization.


## GUI Version
Run `todo_gui.py` for a Tkinter-based GUI To-Do List Application.